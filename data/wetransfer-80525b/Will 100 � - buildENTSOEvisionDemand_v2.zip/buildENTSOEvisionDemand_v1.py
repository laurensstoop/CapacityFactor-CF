"""
buildENTSOEdemand

Program to build demand profiles per country for Plexos, based on 'Visions' released
by ENTSO-E in their TYNDP 2016
"""

import pandas as pd
import numpy as np
import os
import math
import matplotlib
import matplotlib.pyplot as plt
import datetime as dt  # Python standard library datetime  module
from netCDF4 import Dataset  # http://code.google.com/p/netcdf4-python/
import xray
import glob
from pandas import ExcelWriter
import pyximport
import timeit
import time
import sys
import calendar
import csv
import scipy
from scipy import stats
import xlwt

def curtime():
    return dt.datetime.strftime(dt.datetime.now(), '%Y-%m-%d %H:%M:%S')

def getTimestamp(y,m,d,h):
    timestamp = dt.datetime.combine(dt.date(y, m, d), dt.time(h, 0))
    return timestamp




inputFileFolder='D:\\Drive\\University\\Mendeley References\\ENTSOe\\TYNDP 2016\\'
inputFileName='TYNDP2016 market modelling data.xlsx'
inputFilePath= inputFileFolder + inputFileName

outputFileFolder = 'D:\\Projects\\100% RES\\Input Data\\Demand\\'

nodes = ['AT','BE','BG','CH','CY','CZ','DE','DK','EE','EL','ES','FI','FR','GB','HR','HU','IE','IT','LT','LU','LV','NI','NL','NO','PL','PT','RO','SE','SI','SK']





#Define excel writer so can save multiple sheets with different names to the same excel file at the end
writer = ExcelWriter(inputFilePath)

for vision in range(1,2):       # For ENTSOE visions 1-4 (inclusive)
    rawData = pd.read_excel(inputFilePath, sheetname='Demand Vision %s' %vision,keep_default_na=False)   #Read node names from worksheet

    rawData['EL']=rawData.GR
    rawData['DK']=rawData.DKe+rawData.DKw
    rawData['LU']=rawData.LUb+rawData.LUf+rawData.LUg
    rawData['IT']=rawData.LUb+rawData.ITn+rawData.ITsc
    rawData=rawData[nodes]

    for node in rawData.columns:
        nodeData = rawData[node]
        plexosPivot= pd.DataFrame()
        
        for year in range (1979,2016):          #Define list of years to include in load file
            nodeDataYear = nodeData.copy()
            baseTimeIndex = pd.DatetimeIndex(start='%s-01-01 01:00' %(year),end='%s-01-01 00:00' %(year+1),freq='1H')
            nodeDataYear.index = baseTimeIndex

            #Have all base data correct, now to put into format for Plexos
            nodeDataYear['YEAR']=nodeDataYear.index.year
            nodeDataYear['MONTH']=nodeDataYear.index.month
            nodeDataYear['DAY']=nodeDataYear.index.day
            nodeDataYear['HOUR']=nodeDataYear.index.hour
            nodeDataYear['DATE']=pd.DatetimeIndex(nodeDataYear.index).normalize() #extract just the date (without hour)

            #Timestamp year,month,day and hour do not match Plexos inputs
            #   e.g.    Final hour of day is 0 in timestamp, but 24 in Plexos inputs
            #           Final hour of year is in following year
            #Fix this by doing some foward shifting, then replacing missing values at start of year

            #Fix date
            nodeDataYear['DATE']=nodeDataYear['DATE'].shift(1)    #Shift date
            nodeDataYear.loc['%s-01-01 01:00:00' %year,'DATE']=nodeDataYear.loc['%s-01-01 02:00:00' %year,'DATE']

            #Fix year
            nodeDataYear['YEAR']=nodeDataYear['YEAR'].shift(1)    #Shift year
            nodeDataYear.loc['%s-01-01 01:00:00' %year,'YEAR']=year

            #Fix month
            nodeDataYear['MONTH']=nodeDataYear['MONTH'].shift(1)    #Shift month
            nodeDataYear.loc['%s-01-01 01:00:00' %year,'MONTH']=1

            #Fix day
            nodeDataYear['DAY']=nodeDataYear['DAY'].shift(1)    #Shift day
            nodeDataYear.loc['%s-01-01 01:00:00' %year,'DAY']=1

            #Fix hour
            nodeDataYear['HOUR']=nodeDataYear['HOUR'].shift(1)    #Final hour of day is 0 in timestamp, but 24 in Plexos inputs
            nodeDataYear['HOUR']=nodeDataYear['HOUR']+1
            nodeDataYear.loc['%s-01-01 01:00:00' %year,'HOUR']=1

            plexosCols=['YEAR','MONTH','DAY',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

            #As original timeseries do not include data for Feb 29 in leap years, but Plexos will look for these, need to add in. We copy the data for Feb 28.
            if calendar.isleap(year) == True:
                print("%s is a leap year, copying data for Feb 28 to Feb 29..." %year)
                feb28=(nodeDataYear.index >= '%s-02-28 01:00:00' %year) & (nodeDataYear.index <= '%s-03-01 00:00:00' %year)
                leapDayData=nodeDataYear.loc[feb28].copy()
                leapDayData.index=leapDayData.index + dt.timedelta(days=1)    #increase INDEX by 1 day
                leapDayData.DATE=leapDayData.DATE + dt.timedelta(days=1)    #increase DATE column by 1 day
                leapDayData.DAY=leapDayData.DAY                             #Increase DAY column by 1 day
                nodeDataYear=nodeDataYear.append(leapDayData)                      #Append copied data for Feb 29 to existing data
                nodeDataYear=nodeDataYear.sort_index()                        #Resort by timestamp


           
            plexosPivotYear= nodeDataYear.pivot_table(index='DATE',values=location,columns = 'HOUR')
            plexosPivotYear['YEAR']=plexosPivotYear.index.year
            plexosPivotYear['MONTH']=plexosPivotYear.index.month
            plexosPivotYear['DAY']=plexosPivotYear.index.day
            plexosPivotYear=plexosPivotYear.reset_index()       #give simple numerical index (makes appending easier later)
            plexosPivotYear=plexosPivotYear[cols]               #keep only required columns
            plexosPivotYear.columns=cols
            
            del plexosPivotYear.index.name
            del plexosPivotYear.columns.name

            plexosPivot=plexosPivot.append(plexosPivotYear)

        targetFileName = node+'_'+'Load' + '_ENTSO-E Vision %s' %(vision) +'.csv'  #target vRES profile file name, using re-laballed location
        plexosPivot.to_csv(outputFileFolder+targetFileName,sep=';',float_format='%.0f',index=False)

            
    
#Format for Plexos, transpose, fix hours of day etc.

#For all desired years

#Check if leap

#Duplicate Feb 28 if necessary


