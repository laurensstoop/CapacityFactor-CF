# -*- coding: utf-8 -*-
"""
Created on Sat May 13 16:58:42 2017

Code to build load profiles for Plexos 100% RES feasibility study, based on ENTSO-E data, and accounting for increased electrification for HPs and EVs, using totals from Roadmap 2050 (ECF)
and allocating using specific country data. Based on earlier code for RES optimisation study. Except now, we split UK into NI and GB, and exclude MT.

@author: W. Zappa
"""





import pandas as pd
import numpy as np
import os
import math
import matplotlib.pyplot as plt
import datetime as dt  # Python standard library datetime  module
#import matplotlib.pyplot as plt
import xray
import glob

def getTimestamp(y,m,d,h):
    timestamp = dt.datetime.combine(dt.date(y, m, d), dt.time(h, 0))
    return timestamp

def print_full(x):
    pd.set_option('display.max_rows', len(x))
    print(x)
    pd.reset_option('display.max_rows')

#Script which imports data in the raw format of ENTSOE (https://www.entsoe.eu/db-query/consumption/mhlv-all-countries-for-a-specific-month)
#and converts it to timeseries. Then, other changes like scaling or electrification can be applied.

#############Main INPUTS#############################
print('Script started')

baseLoadYear = 2015
weatherDataFolder = 'D:\\Projects\\RES Capacity Optimization\\Profiles\\'

loadFolder='D:\\Drive\\University\\100% RES Feasibility Study\\Load Data\\'
    
    
##############File imports#####################################################################################################################################3
#Read in COUNTRY TOTALs for EVs and HPs
print('Base load year: %s' %(baseLoadYear))
print('Loading input files...')
#countryTotals = pd.read_excel(weatherDataFolder+ 'RESoptimizationGrid.xlsm', sheetname='Load Profile Inputs')    #should update these with own load assumptions
countryTotals = pd.read_excel('D:\\Drive\\University\\100% RES Feasibility Study\\100% RES Study Base Data.xlsm', sheetname='Load Profile Inputs')    #should update these with own load assumptions

countryTotals = countryTotals.set_index('Country')
rawLoad = pd.read_excel(loadFolder + 'Load_Data_%s.xlsx' %(baseLoadYear))

#Read in TIMEZONES for each country
timezones = pd.read_excel('D:\\Drive\\University\\100% RES Feasibility Study\\100% RES Study Base Data.xlsm', sheetname='Timezones',index_col=0)
#timezones = pd.read_excel(weatherDataFolder+ 'RESoptimizationGrid.xlsm', sheetname='Timezones',index_col=0)

#Read in base EV LOAD PROFILES for available countries
EVbaseload = pd.read_excel(loadFolder+'RES Optimization EV Profiles.xlsx', sheetname='HOURLY')





################################################################Get raw BASELOAD data#############################################################################

#Read base hourly country load data

#Assuming for now that all ENTSOE load values are at UTC time, not local time. Have emailed ENTSOE but no response. Should try to confirm this.

print('Loading base demand data...')
countriesfinal =['AT','BE','BG','CH','CY','CZ','DE','DK','EE','EL','ES','FI','FR','GB','HR','HU','IE','IT','LT','LU','LV','NI','NL','NO','PL','PT','RO','SE','SI','SK']


countries = ['AT','BE','BG','CH','CY','CZ','DE','DK','EE','GR','ES','FI','FR','HR','HU','IE','IT','LT','LU','LV','NL','NO','PL','PT','RO','SE','SI','SK','GB','NI']
baseDemand = []

for c in countries:
    df = rawLoad.groupby('Country').get_group(c)
    df=df.drop('Country',axis=1)
    df=df.set_index("Day").stack()
    df=df.reset_index(1)
    df.columns = ['HOUR', c]
    df['HOUR']=df.HOUR.apply(lambda x: x[:2])
    df.loc[df['HOUR'] == '24','HOUR']=0         #In python timestamps, hour 24:00 is considered hour 0:00 of the NEXT DAY
    df['HOUR']=df.HOUR.apply(lambda x: int(x))
    df['date']=pd.to_datetime(df.index)
    df.date=df.date.shift(-1)                   #As the last hour 24:00 is considered the first hour of the next day in Python, need to offset days by 1.
    df.iloc[-1, df.columns.get_loc('date')]=df.iloc[-2, df.columns.get_loc('date')]+dt.timedelta(days=1) #fill in the last hour, then add D,M,Y, then convert to timestamp
    
    df['YEAR'] = df['date'].dt.year
    df['MONTH'] = df['date'].dt.month
    df['DAY'] = df['date'].dt.day
    df['YEAR'] = df.YEAR.apply(lambda x: int(x))
    df['MONTH'] = df.MONTH.apply(lambda x: int(x))
    df['DAY'] = df.DAY.apply(lambda x: int(x))

    df['timestamp']=df.apply(lambda x: getTimestamp(x['YEAR'], x['MONTH'],x['DAY'],x['HOUR']), axis=1)
    df=df.set_index('timestamp')
    baseDemand.append(df)

baseDemand = pd.concat(baseDemand,axis=1)
baseDemand=baseDemand.replace('n.a.', np.nan)         #replace missing values (n.a.) with NaN
baseDemand=baseDemand.replace(0, np.nan)         #replace 0 values (mainly Greece) with NaN
baseDemand['EL']=baseDemand['GR']

#Here I could keep day, month year and output to Plexos if desired
baseDemand=baseDemand[countriesfinal]                 #Only keep the desired country columns
baseDemand=baseDemand.replace(0, np.nan)         #replace missing values (n.a.) with NaN

#Old ENTSOE load data (before transparency platform) appear to be given in local time, so need to shift load values in countries based on their timezone so that timestamp and all values are at UTC
for country in countriesfinal:
    baseDemand[country]=baseDemand[country].shift(-(timezones.loc[country,'UTC_offset'])) #seems correct

baseDemand = baseDemand.interpolate()                 #Linearly interpolate over missing values (removing the NaN values and values from end/start of year)

baseDemand['day']=baseDemand.index.dayofweek+1 #Create column with day of week in base load year (Mon:1-Sunday:7), python code makes it 0-6
baseDemand['hour']=baseDemand.index.hour      #Used to match with EV loads
baseDemand.loc[baseDemand.hour == 0, 'hour'] = 24 #replace all 0 hours with 24
baseDemand.loc[baseDemand.hour == 24, 'day']=baseDemand.loc[baseDemand.hour == 24, 'day']-1   #for hours with hour = 24, day =day-1
baseDemand.loc[baseDemand.day == 0, 'day'] = 1    #correct the few hours on day 7 when the day goes to 0
baseDemand['day_hour']=baseDemand['day'].map(str) + "_" + baseDemand['hour'].map(str) #these day_hour codes are then used for joining the EV loads

finalBaseDemand=baseDemand[countriesfinal] #only keep country loads for final summation, but made separate df so that the day_hour in previous df can be used for EV




###########################################   Electric Vehicle Load (dumb charging) and total load   #########################################################

EVloads = pd.DataFrame()
EVprofileAss=pd.DataFrame()


EVloads = EVloads.set_index(pd.DatetimeIndex(start='%s-01-01 01:00' %(baseLoadYear),end='%s-01-01 00:00' %(baseLoadYear),freq='1H'))
EVloads['day_hour']=baseDemand.day_hour
EVloads['t']=EVloads.index

#make new column with index first so it doesn't disappear
result = pd.merge(EVloads, EVbaseload, on='day_hour')
result=result.sort('t')
result=result.set_index('t')


#OK, now I have the hourly profiles for each country in LOCAL time matching up with the correct days of the year.
# Now just need to shift by time zone, convert to rating factors, then multiply by annual total


for col in ['UK','FR','IT','ES','PL','DE']:                     #convert the EV load profiles (in kW I think) to share of total per hour
    result[col]=result[col]/result[col].sum()                   #in local time

for col in ['UK','FR','IT','ES','PL','DE']:    
    result[col]=result[col].shift(-timezones.loc[col]['UTC_offset'])    #Shift each country by correct TZ offset so that all values are shown at UTC


finalEVdemand = pd.DataFrame()
finalEVdemand = finalEVdemand.set_index(pd.DatetimeIndex(start='%s-01-01 01:00' %(baseLoadYear),end='%s-01-01 00:00' %(baseLoadYear),freq='1H'))


#Need to do for all countries
for country in countriesfinal:
    EVloadCountry=countryTotals.loc[country,'EV_Load_profile']          #Asssign 1 of 5 EV load profiles to each country
    finalEVdemand[country]=result[EVloadCountry]                        #Asssign EV load profile (in UTC time) to each country
    finalEVdemand[country]=finalEVdemand[country].shift(-(timezones.loc[country,'UTC_offset']-timezones.loc[EVloadCountry,'UTC_offset'])) #Shift load so now shown for correct hour in each country
    finalEVdemand[country]=finalEVdemand[country]*countryTotals.loc[country,'EV_TWh']*1000*1000 #multiple hourly load fractions by total per year to get load profiles
    
finalEVdemand=finalEVdemand.interpolate()#interpolate missing hour or two at start/end of year


##################################################################Get load from Building HPs #############################################################################
#This method does not include demand profile from heating hot water, just heating degree hours, but shouldn't matter as the time scale of hot
finalBuildingHPLoad = pd.DataFrame()


#For HDH, which is based on temperature, these should all be at UTC already so no time corrections should be necessary

HDH=pd.read_csv(weatherDataFolder +'HDH_%s.csv' %(baseLoadYear),parse_dates=[0],delimiter=';') #Should update these values, use HDH from TMY or not, or just use median year, warmest and coldest year?
HDH=HDH.set_index('t')
HDH['NI'] = HDH['UK']       #Have not calculated separately for NI, so using UK values
HDH['GB'] = HDH['UK']       #Have not calculated separately for NI, so using UK values


HDH = HDH[countriesfinal]
for col in HDH.columns:                 #Calculate share of total HDH per hour
    HDH[col]=HDH[col]/HDH[col].sum()

for country in countriesfinal:               #Split total building HP load to each hour based on HDH, converting to MW
    finalBuildingHPLoad[country]=HDH[country]*countryTotals.loc[country,'HP_Buildings_TWh']*1000*1000


####################################################################Get load from Industry HPs  #############################################################################

FinalindustryLoad = baseDemand[countriesfinal].copy()

for country in countriesfinal:
    FinalindustryLoad[country]=countryTotals.loc[country,'HP_Industry_TWh']*1000*1000/8760





########Create and output load files#########################################################################3
#Not including industry heat pump here, the profile is just constant and not so interesting

baseDemand_EV=pd.DataFrame()        #Define load profile scenario dfs
baseDemand_HP=pd.DataFrame()
baseDemand_EV_HP=pd.DataFrame()

for country in countriesfinal:           #calculate load profile scenarios
    # Base + EV 
    baseDemand_EV[country] = finalBaseDemand[country] + finalEVdemand[country] #+ FinalindustryLoad[country]
    # Base + HP
    baseDemand_HP[country] = finalBaseDemand[country] + finalBuildingHPLoad[country] #+ FinalindustryLoad[country]
    # Base + EV + HP
    baseDemand_EV_HP[country] = finalBaseDemand[country] + finalBuildingHPLoad[country] + finalEVdemand[country] #+ FinalindustryLoad[country]


#Output individual component load profiles (EV,HP)
finalEVdemand.to_csv(loadFolder+'Demand_EVonly_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)
finalBuildingHPLoad.to_csv(loadFolder+'Demand_HPonly_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)


#Output all final combined load profile scenarios

finalBaseDemand.to_csv(loadFolder+'Demand_Base_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)
baseDemand_EV.to_csv(loadFolder+'Demand_Base_EV_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)
baseDemand_HP.to_csv(loadFolder+'Demand_Base_HP_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)
baseDemand_EV_HP.to_csv(loadFolder+'Demand_Base_EV_HP_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)



#Summary of profiles
countrysummary=pd.DataFrame()
profilesummary=pd.DataFrame(columns=('Total_Demand_GWh', 'Min_Demand_GW', 'Max_Demand_GW'))

countrysummary['Total_Base_GWh']=finalBaseDemand.sum()/1000
countrysummary['Total_BaseEV_GWh']=baseDemand_EV.sum()/1000
countrysummary['Total_BaseHP_GWh']=baseDemand_HP.sum()/1000
countrysummary['Total_BaseEVHP_GWh']=baseDemand_EV_HP.sum()/1000

countrysummary['Min_Base_GW']=finalBaseDemand.min()/1000
countrysummary['Min_BaseEV_GW']=baseDemand_EV.min()/1000
countrysummary['Min_BaseHP_GW']=baseDemand_HP.min()/1000
countrysummary['Min_BaseEVHP_GW']=baseDemand_EV_HP.min()/1000

countrysummary['max_Base_GW']=finalBaseDemand.max()/1000
countrysummary['max_BaseEV_GW']=baseDemand_EV.max()/1000
countrysummary['max_BaseHP_GW']=baseDemand_HP.max()/1000
countrysummary['max_BaseEVHP_GW']=baseDemand_EV_HP.max()/1000

countrysummary.to_csv(loadFolder+'CountryLoadSummary_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)

#Calculate overall parameters for each load profile variant

profilesummary=pd.DataFrame()

profilesummary.loc['Base','Total_Demand_TWh']=finalBaseDemand.sum().sum()/1000/1000
profilesummary.loc['Base','Max_Demand_GW']=finalBaseDemand.sum(axis=1).max()/1000
profilesummary.loc['Base','Min_Demand_GW']=finalBaseDemand.sum(axis=1).min()/1000
profilesummary.loc['Base','Max_Demand_Time']=finalBaseDemand.sum(axis=1).idxmax().strftime("%A %Y-%m-%d %H:%M")
profilesummary.loc['Base','Min_Demand_Time']=finalBaseDemand.sum(axis=1).idxmin().strftime("%A %Y-%m-%d %H:%M")

profilesummary.loc['Base_EV','Total_Demand_TWh']=baseDemand_EV.sum().sum()/1000/1000
profilesummary.loc['Base_EV','Max_Demand_GW']=baseDemand_EV.sum(axis=1).max()/1000
profilesummary.loc['Base_EV','Min_Demand_GW']=baseDemand_EV.sum(axis=1).min()/1000
profilesummary.loc['Base_EV','Max_Demand_Time']=baseDemand_EV.sum(axis=1).idxmax().strftime("%A %Y-%m-%d %H:%M")
profilesummary.loc['Base_EV','Min_Demand_Time']=baseDemand_EV.sum(axis=1).idxmin().strftime("%A %Y-%m-%d %H:%M")

profilesummary.loc['Base_HP','Total_Demand_TWh']=baseDemand_HP.sum().sum()/1000/1000
profilesummary.loc['Base_HP','Max_Demand_GW']=baseDemand_HP.sum(axis=1).max()/1000
profilesummary.loc['Base_HP','Min_Demand_GW']=baseDemand_HP.sum(axis=1).min()/1000
profilesummary.loc['Base_HP','Max_Demand_Time']=baseDemand_HP.sum(axis=1).idxmax().strftime("%A %Y-%m-%d %H:%M")
profilesummary.loc['Base_HP','Min_Demand_Time']=baseDemand_HP.sum(axis=1).idxmin().strftime("%A %Y-%m-%d %H:%M")

profilesummary.loc['Base_EV_HP','Total_Demand_TWh']=baseDemand_EV_HP.sum().sum()/1000/1000
profilesummary.loc['Base_EV_HP','Max_Demand_GW']=baseDemand_EV_HP.sum(axis=1).max()/1000
profilesummary.loc['Base_EV_HP','Min_Demand_GW']=baseDemand_EV_HP.sum(axis=1).min()/1000
profilesummary.loc['Base_EV_HP','Max_Demand_Time']=baseDemand_EV_HP.sum(axis=1).idxmax().strftime("%A %Y-%m-%d %H:%M")
profilesummary.loc['Base_EV_HP','Min_Demand_Time']=baseDemand_EV_HP.sum(axis=1).idxmin().strftime("%A %Y-%m-%d %H:%M")

profilesummary.to_csv(loadFolder+'LoadProfileSummary_%s.csv' %(baseLoadYear),sep=';',float_format='%.1f',)



#Output to Plexos format if desired (by country), need to add this

#Up to here is good

#Check for N/A values, finish summary table

############Calculate and output each load variant (other than base
####
#####Base + HP
#####Base + EV
#####Base + HP + EV
####
####
####
####
####
####
###########################################   Format and output total load for Plexos  #########################################################
####
####def toPlexos(df,year,path,label):
####    #Code to convert a time series (data) into format required for Plexos and output as CSV
####    #
####    #  YEAR MONTH DAY 1 2 3 4 5 6 ...24
####    #  yyyy mm    dd  ... 
####    #  ...
####        
####    df['HOUR'] = df.index.hour
####    df['MONTH'] = df.index.month
####    df['DAY'] = df.index.day
####
####    df['DATE']=df.index
####    pd.DatetimeIndex(df.DATE).normalize()   #could remove this line?
####    df['DATE'] = pd.DatetimeIndex(df.DATE).normalize()
####
####    #Shift dates up by 1
####    df['DATE']=df['DATE'].shift(1)
####    df.loc['%s-01-01 01:00:00' %(year),'DATE']=pd.to_datetime('%s-01-01' %(year))
####
####
####    for col in df:
####        pivot= df.pivot_table(index='DATE',values=col,columns = 'HOUR')
####        pivot['YEAR']=pivot.index.year
####        pivot['MONTH']=pivot.index.month
####        pivot['DAY']=pivot.index.day
####
####        cols=['YEAR','MONTH','DAY',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
####        pivot=pivot[cols]
####        pivot.to_csv('%s\\%s_%s_%.csv' %(path,col,year,label),sep=';',float_format='%.1f',index=False)
######
######
######    
######
######format and output to separate CSV files for plexos input, semicolon delimited, correct headings, on d drive, no decimal points, MWh only, remove electric heating from base loads
######
######                                                                                               
######                                                                                                
######http://stackoverflow.com/questions/8474670/pythonic-way-to-add-datetime-date-and-datetime-time-objects
######
###### Plotting examples from Geert
######import matplotlib.pyplot as plt
###### df[399].plot()
###### plt.show()
###### plt.close()
###### df.sum(axis=1)
###### plt.plot(df.sum(axis=1))
###### plt.show()
###### df.boxplot()
###### df.hist()
######
######
######
######
######
######replacing parts of timestamps e.g. with different year http://pymotw.com/  2/datetime/
######also shows how to split up datetime into attributes, useful later to format for plexos
######
######    
######
######
######
######    
####
####    
##
##
##
##    
##
