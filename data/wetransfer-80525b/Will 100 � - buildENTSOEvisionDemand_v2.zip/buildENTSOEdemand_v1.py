"""
buildENTSOEdemand

Program to build demand profiles per country for Plexos, based on 'Visions' released
by ENTSO-E in their TYNDP 2016
"""

import pandas as pd
import numpy as np
import os
import math
import matplotlib
import matplotlib.pyplot as plt
import datetime as dt  # Python standard library datetime  module
from netCDF4 import Dataset  # http://code.google.com/p/netcdf4-python/
import xray
import glob
from pandas import ExcelWriter
import pyximport
import timeit
import time
import sys
import calendar
import csv
import scipy
from scipy import stats
import xlwt

def curtime():
    return dt.datetime.strftime(dt.datetime.now(), '%Y-%m-%d %H:%M:%S')

def getTimestamp(y,m,d,h):
    timestamp = dt.datetime.combine(dt.date(y, m, d), dt.time(h, 0))
    return timestamp




inputFileFolder='D:\\Drive\\University\\Mendeley References\\ENTSOe\\TYNDP 2016\\'
inputFileName='TYNDP2016 market modelling data.xlsx'
inputFilePath= inputFileFolder + inputFileName

outputFileFolder = 'D:\\Projects\\100% RES\\Input Data\\Demand\\'

nodes = ['AT','BE','BG','CH','CY','CZ','DE','DK','EE','EL','ES','FI','FR','GB','HR','HU','IE','IT','LT','LU','LV','NI','NL','NO','PL','PT','RO','SE','SI','SK']

baseLoadYear= 2050
baseTimeIndex = pd.DatetimeIndex(start='%s-01-01 01:00' %(baseLoadYear),end='%s-01-01 00:00' %(baseLoadYear+1),freq='1H')


#Define excel writer so can save multiple sheets with different names to the same excel file at the end
writer = ExcelWriter(inputFilePath)

for vision in range(1,2):       # For ENTSOE visions 1-4 (inclusive)
    rawData = pd.read_excel(inputFilePath, sheetname='Demand Vision %s' %vision,keep_default_na=False)   #Read node names from worksheet

    rawData['EL']=rawData.GR
    rawData['DK']=rawData.DKe+rawData.DKw
    rawData['LU']=rawData.LUb+rawData.LUf+rawData.LUg
    rawData['IT']=rawData.LUb+rawData.ITn+rawData.ITsc


    rawData=rawData[rawData[nodes]]

    rawData.index = baseTimeIndex
#Format for Plexos, transpose, fix hours of day etc.

#For all desired years

#Check if leap

#Duplicate Feb 28 if necessary


