import pandas as pd
import numpy as np
import os
import math
import matplotlib.pyplot as plt
import datetime as dt  # Python standard library datetime  module
#import matplotlib.pyplot as plt
import xray
import glob

def getTimestamp(y,m,d,h):
    timestamp = dt.datetime.combine(dt.date(y, m, d), dt.time(h, 0))
    return timestamp

def print_full(x):
    pd.set_option('display.max_rows', len(x))
    print(x)
    pd.reset_option('display.max_rows')


#############Main INPUTS#############################
print('Script started')

baseLoadYear = 2017
weatherDataFolder = 'D:\\Projects\\RES Capacity Optimization\\Profiles\\'

loadFolder='D:\\Drive\\Market design article\\Load Data\\'

#Raw load for base year (2017) is in 4 .csv files, one for each country
#rawBaseYearLoad = pd.read_csv(loadFolder+'Load_Series_2017_Best_Estimate.xlsx')

#For the TYNDP 2018 future load scenarios, excel files contain
# 1 sheet per load region (some countries have only 1 sheet, while others spread across multiple sheet)
# Hourly load values (in single column) for three climatic weather years
# First 11 rows are useless

#So should loop through them all

countryList = ['BE','DE','FR','NL']
climateYear = 2007
loadYears = ['raw2020Load','raw2025Load','raw2030Load','raw2040Load']
loadFileNames = {'raw2020Load': 'Load_Series_2020_Best_Estimate.xlsx',
                 'raw2025Load': 'Load_Series_2025_Best_Estimate.xlsx',
                 'raw2030Load': 'Load_Series_2030_EUCO.xlsx',
                 'raw2040Load': 'Load_series_2040_GCA.xlsx'}
years = {'raw2020Load': 2020,
         'raw2025Load': 2025,
         'raw2030Load': 2030,
         'raw2040Load': 2040}


loadData = {loadYear: pd.DataFrame() for loadYear in loadYears}
 

for loadYear in loadYears:
    fileName = loadFileNames[loadYear]  #get load year filename
    year= years[loadYear]
    
    for country in countryList:
        
        data = pd.read_excel(loadFolder+fileName,sheet_name =country,skiprows =10)
        loadData[loadYear][year]=data[climateYear]
        

#raw2020Load= pd.read_excel(loadFolder+'Load_Series_2020_Best_Estimate.xlsx')
#raw2025Load= pd.read_excel(loadFolder+'Load_Series_2025_Best_Estimate.xlsx')
#raw2030Load= pd.read_csv(loadFolder+'Load_Series_2030_EUCO.xlsx')
#raw2040Load= pd.read_csv(loadFolder+'Load_series_2040_GCA.xlsx')

#Align for days of week

#Convert from 15 to hourly

#Interpolate missing years
 #for each country, put hours in rows, years in columns, interpolate, then melt back into one column

#Deal with leap years

#Convert to Plexos format
