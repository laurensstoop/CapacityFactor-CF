import pandas as pd
import numpy as np
import os
import math
import matplotlib.pyplot as plt
import scipy
from scipy.stats import norm
import datetime as dt  # Python standard library datetime  module
#import matplotlib.pyplot as plt
import xray
import glob
import calendar
import random
from dateutil.relativedelta import relativedelta

def getTimestamp(y,m,d,h):
    timestamp = dt.datetime.combine(dt.date(y, m, d), dt.time(h, 0))
    return timestamp

def print_full(x):
    pd.set_option('display.max_rows', len(x))
    print(x)
    pd.reset_option('display.max_rows')


#############Main INPUTS#############################
print('Script started')

baseLoadYear = 2017

#loadFolder='N:\\GEO\\IMEW\\Sectie ER\\Personal directories staff\\William\\vRES Market Design\\Load Data\\'
loadFolder='O:\\vRES Market Design\\Load Data\\'

#outputFolder = 'N:\\GEO\\IMEW\\Sectie ER\\Personal directories staff\\William\\vRES Market Design\\Load Data\\Test\\'
outputFolder = 'O:\\vRES Market Design\\Load Data\\Test\\'

seedFolder = 'O:\\vRES Market Design\\'

#Raw load for base year (2017) is in 4 .csv files, one for each country
#rawBaseYearLoad = pd.read_csv(loadFolder+'Load_Series_2017_Best_Estimate.xlsx')

#For the TYNDP 2018 future load scenarios, excel files contain
# 1 sheet per load region (some countries have only 1 sheet, while others spread across multiple sheet)
# Hourly load values (in single column) for three climatic weather years
# First 11 rows are useless

#So should loop through them all

countryList = ['BE','DE','FR','NL','AT','CH','CZ','DK','ES','GB','IT','NO','PL','SE'] # ['BE','DE','FR','NL','AT','CH','CZ','DK','ES','GB','IT','NO','PL','SE']
countrySeedList = pd.read_excel(seedFolder+"countryRandomNumberSeeds.xlsx",index_col=0) #This is a list of random number seeds specific to each country, so you get the same forecast errors each time you run the code

climateYear = 2007
baseYear = 2017
finalYear = 2041
baseYearOffsetShiftDays = -1   #Number of days to shift base year data. Future year load data scenarios start with Jan 1 as Monday, while Jan 1 of 2017 was Sunday. So, need to shift base load data back by 1 day so that it also starts on a Monday. Otherwise, interpolation will be weird
loadYears = ['raw2020Load','raw2025Load','raw2030Load','raw2040Load']
loadFileNames = {'raw2020Load': 'Load_Series_2020_Best_Estimate.xlsx',
                 'raw2025Load': 'Load_Series_2025_Best_Estimate.xlsx',
                 'raw2030Load': 'Load_Series_2030_DG.xlsx',
                 'raw2040Load': 'Load_series_2040_GCA.xlsx'}
years = {'raw2020Load': 2020,
         'raw2025Load': 2025,
         'raw2030Load': 2030,
         'raw2040Load': 2040}

dayAheadMAE = 0.026 #Mean absolute error of day-ahead forecasts, given as % mean annual load
dayAheadStdDevError = 0.032 #Standard deviation of the day-ahead forecast errors, given as % of mean annual load


#Dataframe to store the mean annual load per year per country
averageYearlyLoad = pd.DataFrame(columns=countryList)

countryLoadData = {country: pd.DataFrame() for country in countryList}


dayMonthIdx = pd.date_range('2001-01-01 00:00:00', freq='1H', periods=8760).shift(1) #hourly index for standard (non-leap) year, taken as 2001


allYearIdx = pd.DataFrame(index=range(baseYear,finalYear+1,1))

allYears= list(range(baseYear,finalYear+1))

leapYears=[]
for year in allYears:
    if calendar.isleap(year)==True:
        leapYears.append(year)
        

for country in countryList:
    print("Starting country: %s" %(country))

    #Get base load year

    baseLoadFileName= "%s - Total Load - Day Ahead _ Actual_%s.csv" %(country,baseYear)
    #baseYearLoad = pd.read_csv(loadFolder+baseLoadFileName,header=0,names=['tstamp','Load'],usecols =[0,2])
    baseYearLoad = pd.read_csv(loadFolder+baseLoadFileName,header=0,names=['tstamp','Forecast','Actual'],usecols =[0,1,2])
    baseYearLoad.Actual.fillna(baseYearLoad.Forecast, inplace=True) #Replace NaN values in Actual load values with forecasted values
    
    if country in ['DE','BE','NL','AT']: #Countries with 15 min load data
        baseYearTstamp = pd.date_range('%s-01-01 00:15:00' %(baseYear), freq='15T', periods=35040)
        baseYearLoad.index=  baseYearTstamp
        #baseYearLoad=baseYearLoad.resample('1H', label='right', closed='right') #Resample to hourly, averaging the values for 15 minutes across the hour, and reporting at the end of the hour.
                                                                            #Thus, value at 01:00:00 is the average of the values at 00:15:00,00:30:00,00:45:00, and 01:00:00
        baseYearLoad=baseYearLoad.resample('1H', label='right', closed='right').mean()                                                                        


    elif country in ['GB']:               #Countries with 30min load data
        baseYearTstamp = pd.date_range('%s-01-01 00:30:00' %(baseYear), freq='30T', periods=17520)
        baseYearLoad.index=  baseYearTstamp
        #baseYearLoad=baseYearLoad.resample('1H', label='right', closed='right')
        baseYearLoad=baseYearLoad.resample('1H', label='right', closed='right').mean()  #new python version requires the .mean(), as resample now just returns a resampler object



    elif country in ['FR','DK','CH','CZ','ES','NO','PL','SE','IT']:               #Countries with hourly load data
        baseYearTstamp = pd.date_range('%s-01-01 01:00:00' %(baseYear), freq='1H', periods=8760)
        baseYearLoad.index=  baseYearTstamp

    else:
        print("Country %s load step not known..." %(country))
        
        

    
    baseYearLoad=baseYearLoad.shift(24*baseYearOffsetShiftDays)

    baseYearLoad.iloc[-24:,:]=baseYearLoad.iloc[-48:-24,:].values           #Fill missing data now created on 31 Dec with data from 30th Dec
    

    
    countryLoadData[country][baseYear]=baseYearLoad.Actual.values


    #Shift 2017 load data days to match future data (Jan 1 is Monday)

    
    
    #Get future load years
    for loadYear in loadYears:
        
        fileName = loadFileNames[loadYear]  #get load year filename
        year= years[loadYear]

        print("Starting year: %s" %(year))
    
    
        
        data = pd.read_excel(loadFolder+fileName,sheetname =country,skiprows =10)
        countryLoadData[country][year]=data[climateYear]

        #After getting raw data, hours are in rows, years are in columns

        #-----End load year loop

    #Output raw uninterpolated results
    
    #countryLoadData[country].to_csv(outputFolder+'Raw Key Year Loads_%s.csv' %(country),delimiter=";")
    countryLoadData[country].to_csv(outputFolder+'Raw Key Year Loads_%s.csv' %(country),sep=";")  #New python version

    df=countryLoadData[country]
    df=df.transpose()
    df=df.reindex_axis(allYearIdx.index)
    df=df.interpolate(method='linear')
    df=df.transpose()
    countryLoadData[country]=df

    countryLoadData[country].index=dayMonthIdx  #replace the 0-8759 index with standard (non-leap) datetime index

    countryLoadData[country]=countryLoadData[country].unstack()     #Moves all years from columns to rows, so all values in one column, with a multiindex

    countryLoadData[country]=countryLoadData[country].reset_index() #Removes multi-index

    countryLoadData[country]['LOAD']=countryLoadData[country][0]

    
    countryLoadData[country]['YEAR']=countryLoadData[country]['level_0']
    
    countryLoadData[country]['MONTH']=countryLoadData[country]['level_1'].dt.month
    countryLoadData[country]['MONTH']=countryLoadData[country]['MONTH'].shift(1)
    countryLoadData[country].loc[0,'MONTH']=1
    
    countryLoadData[country]['DAY']=countryLoadData[country]['level_1'].dt.day
    countryLoadData[country]['DAY']=countryLoadData[country]['DAY'].shift(1)
    countryLoadData[country].loc[0,'DAY']=1
    
    countryLoadData[country]['HOUR']=countryLoadData[country]['level_1'].dt.hour
    countryLoadData[country].loc[countryLoadData[country]['HOUR'] == 0,'HOUR'] = 24

    for year in leapYears:
        feb29Data=countryLoadData[country].loc[(countryLoadData[country]['YEAR']==year) & (countryLoadData[country]['MONTH']== 2) & (countryLoadData[country]['DAY']== 28)].copy()
        feb29Data['DAY']=29           #Add an extra day for 29th Feb in leap years which is a copy of 28th Feb
        #countryLoadData[country].loc[(countryLoadData[country]['YEAR']==year) & (countryLoadData[country]['MONTH']== 2) & (countryLoadData[country]['DAY']== 29)]=feb29Data
        countryLoadData[country]=countryLoadData[country].append(feb29Data)

    countryLoadData[country]["LOAD"]=countryLoadData[country].LOAD.round(0)    #Need to round numbers (to MW), otherwise Plexos won't accept them
    
    #Output the REAL TIME/ACTUAL LOAD
    #----------------------------------------------------------
    countryLoadData[country].pivot_table(index=['YEAR','MONTH','DAY'],values='LOAD',columns='HOUR').to_csv(outputFolder+'Load_%s_ACT.csv' %(country))

    #Now output as timeseries for checking
    countryLoadData[country]['origDtString']=countryLoadData[country]['level_1'].apply(lambda x: x.strftime("%Y-%m-%d %H:%M:%S"))
    countryLoadData[country]['newDtString']=countryLoadData[country]['YEAR'].apply(str)+countryLoadData[country]['origDtString'].str[4:]
    countryLoadData[country]['newDtString']=pd.to_datetime(countryLoadData[country]['newDtString'])
    
    countryLoadData[country]=countryLoadData[country].set_index('newDtString')
    countryLoadData[country]=countryLoadData[country].sort_index()
    countryLoadData[country]['LOAD'].to_csv(outputFolder+'Load_ACT_%s_timeseries.csv' %(country))

    #Now calculate and output the Day-Ahead FORECAST LOAD
    #---------------------------
    
    #First, create list of unique random numbers for all hours, seeded with specific value per country, so can make the same numbers each time the code is run
    random.seed(countrySeedList.loc[country].Load) #initialise the seed
    countryLoadData[country]['random']=[random.random()  for i in countryLoadData[country].index] #generate a unique random number betwen 0 and 1 for each row
    
    #First calculate the mean annual laod per year (needed as forecast errors are given as % of annual mean load)   
    for year in allYears:

        meanLoad = countryLoadData[country]['LOAD'].loc[countryLoadData[country]['LOAD'].index.year==year].mean()
        averageYearlyLoad.loc[year,country]=meanLoad
        
        #yearData = countryLoadData[country].loc[countryLoadData[country].index.year==year]
        countryLoadData[country].loc[countryLoadData[country].index.year==year,'DA forecast error']=norm.ppf(countryLoadData[country].loc[countryLoadData[country].index.year==year,'random'], loc=0, scale=meanLoad*dayAheadStdDevError) #Generate value using inverse of normal distribution. loc is the mean, scale is standard deviation
        
    countryLoadData[country]['DAforecast']=countryLoadData[country]['DA forecast error']+countryLoadData[country]['LOAD']
    #countryLoadData[country]["DAforecast"]=countryLoadData[country].DAforecast.round(0)
    
    countryLoadData[country]["DAforecastSmoothed"]=countryLoadData[country].DAforecast
        
    autoCorrelationWeight = 0.3
    newForecastWeight = 0.7
    
    #If I want to do the smoothing loop, it would need to be here.
    #Instead of smoothing like this though, make a new column with x% step in seperate column, then shift, then add columns
    
    countryLoadData[country]["autoCorComp"]=autoCorrelationWeight*countryLoadData[country]["DAforecast"]
    countryLoadData[country]["autoCorComp"]=countryLoadData[country]["autoCorComp"].shift(1) #shift forward one timestep so when adding columns, adding from the previous timestep
    countryLoadData[country]["autoCorComp"]=countryLoadData[country]["autoCorComp"].fillna(method='bfill') #fill the first period with the last value known
    
    countryLoadData[country]["DAforecastSmoothed"]=countryLoadData[country]["DAforecast"]*newForecastWeight+countryLoadData[country]["autoCorComp"]
    countryLoadData[country]["DAforecastSmoothed"]=countryLoadData[country]["DAforecastSmoothed"].round(0)
  
    #Currently using smoothed forecasts, which use ~30% of the the previous timestep DA forecast and 70% the proposed DA forecast
    #Doing this as just applying the DA error to the actual data gives a bit of a jagged profile, while in reality the forecast error holds over a whole day/week, and is not quite so variable from
    #hour to hour. Applying this small smoothing leads to slightly smoother forecast profile, without changing the overall forecast accuracy metrics very much compared with the ENTSOE accuracy    
    countryLoadData[country].pivot_table(index=['YEAR','MONTH','DAY'],values='DAforecastSmoothed',columns='HOUR').to_csv(outputFolder+'Load_%s_DAfc.csv' %(country))

    #---------------------------------------    -------------------   






    #-----End country loop
    

    

        
        
    

#df=q.reindex_axis(allYearIdx.index)
#q=q.interpolate(method='linear')

#Add index to each dataframe of countryLoadData
        
#Align for days of week

#Convert from 15 to hourly

#Interpolate missing years
 #for each country, put hours in rows, years in columns, interpolate, then melt back into one column

#Deal with leap years

#Convert to Plexos format
